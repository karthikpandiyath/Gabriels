import json
import boto3
import time
import botocore
import os
def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')
    instance_id = event['detail']['EC2InstanceId']
    lifecycle_action_token = event['detail']['LifecycleActionToken']
    domain_username = os.environ['DOMAIN_USERNAME']
    domain_password = os.environ['DOMAIN_PASSWORD']
    # PowerShell command to run on the instances
    powershell_command = [
        'Enable-WindowsOptionalFeature -FeatureName ActiveDirectory-Powershell -Online -All',
        'Import-Module ActiveDirectory',
        'Install-WindowsFeature rsat-dns-server',
        f"$securePassword = ConvertTo-SecureString '{domain_password}' -AsPlainText -Force",
        f"$credential = New-Object System.Management.Automation.PSCredential ('gabriels.net\\{domain_username}', $securePassword)",
        f"$DCHostName = (Get-ADDomainController -Discover).HostName",
        f"$MachineName = $env:COMPUTERNAME",
        'Remove-ADComputer -Identity $MachineName -Credential $credential -Server "$DCHostName" -Confirm:$false'
    ]
    # SSSM document to use for the command (default: AWS-RunPowerShellScript)
    document_name = 'AWS-RunPowerShellScript'
    ssm = boto3.client('ssm')
    autoscaling_client = boto3.client('autoscaling')
    response = ssm.send_command(
        InstanceIds=[instance_id],
        DocumentName='AWS-RunPowerShellScript',
        Parameters={
            'commands': powershell_command
        }
    )
    command_id = response['Command']['CommandId']
    instance_id = response['Command']['InstanceIds'][0]
    status = 'Pending'
    while status == 'Pending' or status == 'InProgress':
        time.sleep(5) # Wait for 5 seconds before polling again
        invocations = ssm.list_command_invocations(
            CommandId=command_id,
            InstanceId=instance_id
        )
        status = invocations['CommandInvocations'][0]['Status']
        if status == 'Failed':
            print('Script execution failed')
            break
    # Print the command response (stdout and stderr) for each instance
    command_id = response['Command']['CommandId']
    command_invocation = ssm.get_command_invocation(
        CommandId=command_id,
        InstanceId=instance_id
    )
    response = autoscaling_client.complete_lifecycle_action(
        LifecycleHookName='AffinityWebLifecylehook',
        AutoScalingGroupName='AffinityWebASG',
        LifecycleActionResult='CONTINUE',
        InstanceId=instance_id,
        LifecycleActionToken=lifecycle_action_token
    )
    print(f"Standard Output: {command_invocation['StandardOutputContent']}")
    print(f"Standard Error: {command_invocation['StandardErrorContent']}")