#this is the first lambda function that creates an ami and stores the ami id to ssm parameter store
import os
import json
import boto3
import time

def lambda_handler(event, context):
    # Set the ID of the EC2 instance that you want to use as the basis for the new AMI
    instance_id = os.environ.get('instance_id_envar')
    
    
    currDate = time.strftime("%d%m%y")
    currTime = time.strftime("%H%M%S")
    
    # Create an EC2 client
    ec2 = boto3.client('ec2')

    # Create a new AMI of the existing instance
    response = ec2.create_image(InstanceId=instance_id, Name="GAB_ASG_Test_AMI_%s_%s" % (currDate, currTime), Description='an ami created for gab asg on 30052023')
    ami_id = response['ImageId']
    print(ami_id)
    
    # Add tags to the new AMI
    ec2.create_tags(Resources=[ami_id], Tags=[{'Key': 'Environment', 'Value': 'Production'}, {'Key': 'Application', 'Value': 'MyApp'},
    {'Key': 'run', 'Value': 'lambda2'}])
    
    
    # Return the ID of the new AMI
    ssm_client = boto3.client('ssm')
    response = ssm_client.put_parameter(
        Name='GAB_AMI',
        Description='AMI of Win with firefox instance',
        Value=ami_id,
        Type='String',
        Overwrite=True
    )
    message = {
   'message': 'Execution started successfully!'+'New AMI ID:'+ami_id
    }
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps(message)
    }