import json
import boto3
import time
import sys
import os

def lambda_handler(event, context):
    
    # Set the desired tags to match
    required_tags = {'Environment': 'Production', 'Application': 'MyApp','run': 'lambda2'}
    
    currDate = time.strftime("%d%m%y")
    currTime = time.strftime("%H%M%S")
    LCNAME = "GAB_LC_%s_%s" % (currDate, currTime)

    asg_name = os.environ.get('asg_name_envar')
    instance_id = os.environ.get('instance_id_envar')

    # Set the desired Instance Type, MinSize and MaxSize
    instance_type = 't3.2xlarge'
    min_size =  int(os.environ.get('min_ec2_env'))
    max_size =  int(os.environ.get('max_ec2_env'))
    des_size =  int(os.environ.get('des_ec2_env'))

    # Retrieve the AMI ID of the EC2 instance
    ssm = boto3.client('ssm')
    parameter_name = 'GAB_AMI'
    response = ssm.get_parameter(Name=parameter_name, WithDecryption=True)
    parameter_value = response['Parameter']['Value']
    ami_id = parameter_value
    
    
    # Retrieve the tags of the AMI
    ec2 = boto3.resource('ec2')
    ami = ec2.Image(ami_id)
    ami_tags = {tag['Key']: tag['Value'] for tag in ami.tags}
    
    # Check if the required tags match the AMI tags
    if not all(key in ami_tags and ami_tags[key] == value for key, value in required_tags.items()):
        return {
            'statusCode': 400,
            'body': 'AMI does not have the required tags.'
        }    
    
    
    # Set the name of the Launch Configuration and Auto Scaling Group to update

    # Get old lc name
    #ssm_client = boto3.client('ssm')
    parameter_name = "gab_lc_name"
    response = ssm.get_parameter(Name=parameter_name, WithDecryption=True)
    parameter_value = response['Parameter']['Value']
    launch_configuration_name = parameter_value

    # Return the launch config name
    ssm_client = boto3.client('ssm')
    response = ssm_client.put_parameter(
        Name='gab_lc_name',
        Description='LC of instance',
        Value=LCNAME,
        Type='String',
        Overwrite=True	 
    )

    #ssm_client = boto3.client('ssm')
    parameter_name = "user_data_script"
    response = ssm.get_parameter(Name=parameter_name, WithDecryption=True)
    parameter_value = response['Parameter']['Value']
    user_data = parameter_value    

    ec2_client = boto3.client('ec2')
    response = ec2_client.describe_images(ImageIds=[ami_id])
    snapshot_id = response['Images'][0]['BlockDeviceMappings'][0]['Ebs']['SnapshotId']

    # Get the details of the existing Launch Configuration
    autoscaling = boto3.client('autoscaling', region_name='us-east-1')
    response = autoscaling.describe_launch_configurations(LaunchConfigurationNames=[launch_configuration_name])
    launch_configuration = response['LaunchConfigurations'][0]
    

    new_block_device_mappings = [
        {
            'DeviceName': '/dev/xvda',
            'Ebs': {
                'SnapshotId': snapshot_id,
                'VolumeSize': 30  # Set the desired volume size in GB
                # 'VolumeType':  #launch_configuration['BlockDeviceMappings'][0]['Ebs']['VolumeType'],  # Set the desired volume type
                # 'DeleteOnTermination': True
            }
        }
    ]
    # Update the Launch Configuration with the new AMI ID and Instance Type
    response = autoscaling.create_launch_configuration(
        LaunchConfigurationName=LCNAME,
        ImageId=ami_id,
        InstanceType=launch_configuration['InstanceType'],
        KeyName=launch_configuration['KeyName'],
        SecurityGroups=launch_configuration['SecurityGroups'],
        UserData=user_data,
        #launch_configuration['UserData'],
        BlockDeviceMappings=new_block_device_mappings,
        InstanceMonitoring={'Enabled': launch_configuration['InstanceMonitoring']['Enabled']}
    )

    # Get the details of the existing Auto Scaling Group
    response = autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    asg = response['AutoScalingGroups'][0]

    # Update the Auto Scaling Group to use the new Launch Configuration and desired MinSize and MaxSize
    response = autoscaling.update_auto_scaling_group(
        AutoScalingGroupName=asg_name,
        LaunchConfigurationName=LCNAME,
        MinSize=min_size,
        MaxSize=max_size,
        DesiredCapacity=des_size,
        NewInstancesProtectedFromScaleIn=False  # Protect new instances from scale-in during Instance Refresh
    )

    # Initiate an Instance Refresh for the Auto Scaling Group
    response = autoscaling.start_instance_refresh(
        AutoScalingGroupName=asg_name,
        Strategy='Rolling',
        Preferences={
            'MinHealthyPercentage': 30,
            'InstanceWarmup': 60,  # Warmup time in seconds
            'CheckpointDelay': 60,  # Delay between replacing instances in seconds
            'CheckpointPercentages': [30, 60, 90]  # Checkpoint percentages for instance replacement
        }
    )

    # Delete the old Launch Configuration
    #response = autoscaling.delete_launch_configuration(LaunchConfigurationName=launch_configuration_name)

    # Return a success message
    return 'Launch Configuration updated successfully and Instance Refresh initiated'
