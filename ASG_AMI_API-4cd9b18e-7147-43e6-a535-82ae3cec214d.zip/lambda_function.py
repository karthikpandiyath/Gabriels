import boto3
import base64
import json
import re
def get_ami_status(ami_id):
    ec2_client = boto3.client('ec2')
    try:
        response = ec2_client.describe_images(ImageIds=[ami_id])
        if 'Images' in response and len(response['Images']) > 0:
            ami_status = response['Images'][0]['State']
            return f"AMI Status: {ami_status}"
        else:
            return "AMI not found."
    except Exception as e:
        return f"Error: {str(e)}"
def lambda_handler(event, context):
    # Replace 'YOUR_AMI_ID' with the actual AMI ID you want to check
    print(event["body"])
    data = base64.b64decode(event["body"])
    decoded_string = data.decode("utf-8")
    decoded_string = decoded_string.replace("\r", "").replace("\n", "")
    print(decoded_string)
    # decoded_string = json.loads(decoded_string)
    # decoded_string.replace(""," ")
    decoded_string = eval(decoded_string)
    type = decoded_string["type"]
    if type == "ami":
        ami_id = decoded_string["ami_id"]
        ami_status = get_ami_status(ami_id)
        return {
            'statusCode': 200,
            'body': ami_status
        }
    else:
        client = boto3.client('autoscaling', region_name='us-east-1')
        response = client.describe_instance_refreshes(AutoScalingGroupName='AffinityWebASG',)
        print(response)
        instance_refresh_status=json.dumps(response, default=str)
        return {
            'statusCode': 200,
            'body': instance_refresh_status
        }